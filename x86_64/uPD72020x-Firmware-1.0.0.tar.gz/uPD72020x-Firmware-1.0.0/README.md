# uPD72020x_firmware
 Firmware for the uPD720201 and uPD720202 (+Flashing utility (def x64)) (2.0.1.3, 2.0.2.0, 2.0.2.6) (+ Win driver)
